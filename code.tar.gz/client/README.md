## Overview
This is the "Quickstart React" example Monday app. 
<br>It can be used as a board view, item view or any other view, connected to a board and render data from the board using settings.



## Run the project

In the project directory, you should run:
 

```bash
npm install
```

And then to run an application with the monday tunnel, run:


```bash
npm run dev
```

Open [http://localhost:8301](http://localhost:8301) to view it in the browser.
